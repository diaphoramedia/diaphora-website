﻿=====================

Theme Name: JustWrite
Theme URI: http://www.acosmin.com/theme/justwrite/
Author: Alexandru Cosmin

JustWrite WordPress Theme, Copyright 2015 Acosmin.com
JustWrite is distributed under the terms of the GNU GPL

=====================

Documentation @ http://www.acosmin.com/documentation/justwrite/
Changelog @ http://changelog.acosmin.com/justwrite/wporg/
News & Updates @ http://www.acosmin.com/blog/

=====================

Resources:

jCarousel v0.3.0 jQuery script - ​http://sorgalla.com/jcarousel
License: Distributed under the terms of the MIT license
Copyright: Jan Sorgalla, sorgalla.com
___________

Superfish v1.4.8 jQuery script - ​http://users.tpg.com.au/j_birch/plugins/superfish/
License: Distributed under the terms of the MIT and GPL licenses
Copyright: Joel Birch
____________

FitVids v1.1 jQuery script - ​http://fitvidsjs.com/
License: Distributed under the terms of the WTFPL license
Copyright: Chris Coyier - css-tricks.com + Dave Rupert - daverupert.com
____________

HTML5 Shiv v3.7 script - https://github.com/aFarkas/html5shiv
License: Distributed under the terms of the MIT and GPL2 licenses
Copyright: @afarkas @jdalton @jon_neal @rem
____________

Font Awesome v4.7.0 icon set - http://fortawesome.github.io/Font-Awesome/
License: Font Awesome licensed under SIL OFL 1.1 / Code licensed under MIT License
Copyright: Dave Gandy, twitter.com/davegandy
____________

Owl carousel v2.0.0 jQuery script - http://www.owlcarousel.owlgraphic.com/
License: Distributed under the terms of the MIT license
Copyright: Bartosz Wojciechowski
____________

imagesLoaded v3.1.0 jQuery script - http://imagesloaded.desandro.com/
License: Distributed under the terms of the MIT license
Copyright: Oliver Caldwell


JustWrite Screenshot - Images used:
https://www.flickr.com/photos/paradox_and_confusion/14752706508/
https://www.flickr.com/photos/cop21/23053866559/
https://www.flickr.com/photos/133042043@N04/20475024129/
https://www.flickr.com/photos/136375272@N05/21773064491/
License: Public Domain CC0
All images are from Pixabay - http://flickr.com/
